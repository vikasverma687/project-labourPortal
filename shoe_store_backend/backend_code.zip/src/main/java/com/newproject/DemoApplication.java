package com.newproject;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class DemoApplication {

	@Value("${app.allowed-origins}")
	private String allowedOrigins;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

}
