package com.newproject.security;

import com.newproject.service.JwtService;
import com.newproject.service.LoginService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

@Configuration
public class JwtAuthFilter extends OncePerRequestFilter {

    @Autowired
    JwtService jwtService;

    @Autowired
    LoginService loginService;

    private static final List<String> PUBLIC_PATHS = List.of(
            "/api/auth/register",
            "/api/auth/login",
            "/api/auth/forgot-password",
            "/api/auth/reset-password",
            "/api/v2/allproducts",
            "/api/v2/women-products",
            "/api/v2/kids-products",
            "/api/v2/men-products",
            "/api/v2/product",
            "/api/v2/view-comment",
            "/api/v2/search-products",
            "/uploads/"
    );


    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getServletPath();


        if (request.getMethod().equalsIgnoreCase("OPTIONS")) {
            return true;
        }
        if (path.startsWith("/uploads/")) {
            return true;
        }


        return PUBLIC_PATHS.stream().anyMatch(path::startsWith);

    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {


        String authHeader = request.getHeader("Authorization");

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            response.setStatus(401);
            response.getWriter().write("token not found, or bad request made!!");
            return;
        }

        String token = authHeader.substring(7);
        String role = "";
        String email = "";

        try {
            Claims claims = jwtService.parseClaims(token);
            email = claims.getSubject();
            role = (String) claims.get("role");
        } catch (ExpiredJwtException e) {
            response.getWriter().write("access token expired, trying to create new access token from refresh token..");

            Claims claims = e.getClaims();

            role = (String) claims.get("role");
            email = claims.getSubject();

            String newtoken = loginService.tryRefreshToken(email, role);
            if (newtoken != null) {
                System.out.println("access token generated again");
                response.setStatus(200);
                response.setHeader("NEW-ACCESS-TOKEN", newtoken);
                response.setHeader("Access-Control-Expose-Headers", "New-Access-Token");
                return;
            } else {

                response.setStatus(403);
                response.getWriter().write("your refresh token is also expired, login again!!");
                return;
            }
        }

        request.setAttribute("email", email);
        request.setAttribute("role" , role);

        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
                email, null, List.of(new SimpleGrantedAuthority("ROLE_" + role)));

        SecurityContextHolder.getContext().setAuthentication(authentication);

        filterChain.doFilter(request, response);

    }
}
