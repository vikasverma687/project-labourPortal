package com.newproject.Controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @GetMapping("/adminpanel")
    public ResponseEntity<?> handleAdminPanel(HttpServletRequest request) {

        String role = (String) request.getAttribute("role");

        System.out.println("role is ="+ role);
        if (!role.equals("ADMIN")) {

            return ResponseEntity.status(401).body(Map.of("message", "you are not authorized for this action"));
        }
        return ResponseEntity.ok(Map.of("message", "welcome admin"));

    }

}
