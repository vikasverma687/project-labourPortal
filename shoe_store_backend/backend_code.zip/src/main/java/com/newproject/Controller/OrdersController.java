package com.newproject.Controller;


import com.newproject.DAO.OrdersDao;
import com.newproject.service.OrdersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RequestMapping("api/v2/orders")
@RestController
public class OrdersController {

    @Autowired
    OrdersService ordersService;

    @Autowired
    OrdersDao ordersDao;


    @PostMapping("/place-orders")
    public ResponseEntity<?> placeOrders(@RequestParam int user_id) {

            ordersService.placeorder(user_id);
            return ResponseEntity.ok(Map.of("message", "inserted successfuly into allorders-backend"));

    }

    @GetMapping("/fetch-orders")
    public ResponseEntity<?> fetchOrders(@RequestParam int user_id) {

        List<Map<String, Object>> items = ordersService.fetchOrders(user_id);

        if (items != null) {

            return ResponseEntity.ok(Map.of("data", items, "message", "fetched successfuly"));
        } else {

            return ResponseEntity.status(200).body(Map.of("message", "no orders placed!"));
        }
    }

    @DeleteMapping("/remove-item")
    public ResponseEntity<?> removeItem(@RequestParam int user_id , @RequestParam int product_id) {


        if (ordersDao.removeItem(user_id,product_id)) {

            return ResponseEntity.ok(Map.of("message", "removed!!"));
        } else {
            throw new RuntimeException("couldnt delete");
        }

    }

    @DeleteMapping("/delete-all")
    public ResponseEntity<?> deleteAll(@RequestParam int user_id) {
        try {
            ordersDao.deleteAll(user_id);
            return ResponseEntity.ok(Map.of("message", "discarded all items!"));
        } catch (Exception e) {
            throw new RuntimeException("all-delte not working", e);
        }
    }

}
