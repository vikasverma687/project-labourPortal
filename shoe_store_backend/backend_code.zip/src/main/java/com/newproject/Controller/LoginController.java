package com.newproject.Controller;

import com.newproject.DAO.LoginDao;
import com.newproject.DTO.LoginForm;
import com.newproject.service.JwtService;
import com.newproject.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Date;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class LoginController {


    @Autowired
    LoginService loginService;
    @Autowired
    LoginDao loginDao;
    @Autowired
    JwtService jwtService;

    @Autowired
    PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public ResponseEntity<?> Login(@RequestParam String email , @RequestParam String password) {

System.out.println("email is ="+ email + "password is ="+ password);
        validateemail(email);
        validatepassword(password);

        boolean isFound = loginService.setLogin(email, password);
        String role = loginDao.getRole(email);


        if (isFound) {

            Integer user_id = loginDao.getUserId(email);
            String token = jwtService.generateToken(email, role);
            String rtToken = jwtService.generateRefreshToken(email);
            String username = loginDao.getUsername(email);

            if (loginDao.getRT(email) == null) {
                loginService.setRefreshToken(rtToken, email);
            }
            return ResponseEntity.ok(Map.of("token", token, "message", "Login successful", "user_id", user_id, "role",role,"username",username));
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "could not Login");
        }

    }

    private void validateUsername(String username) {

        if (username == null || username.isBlank()) {

            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "username is required");
        }
    }

    private void validateemail(String email) {

        if (email == null || email.isBlank()) {

            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "email is required");
        }

    }

    private void validatepassword(String password) {

        if (password == null || password.isBlank()) {

            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "password is required");
        }

    }

    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotpassword(@RequestParam String email) {

        System.out.println("forgotpassword in contoller hits , email is " + email);
        if (loginService.getResetLink(email)) {

            return ResponseEntity.ok(Map.of("message", "link sent on email"));
        } else {
            return ResponseEntity.status(404).body(Map.of("message", "something went wrong check loginservice"));
        }
    }

    @PostMapping("/reset-password")
    public ResponseEntity<?> resetpassword(@RequestParam String password, String token) {

        System.out.println("password-reset in controller hits, password is " + password);
        System.out.println("password-reset in controller hits, token is " + token);


        List<Map<String, Object>> row = loginDao.getEmailExpiryByToken(token);

        Map<String, Object> data = row.get(0);

        String email = (String) data.get("email");
        Date expiry = (Date) data.get("expiry");

        if (expiry.before(new Date())) {
            return ResponseEntity.status(404).body(Map.of("message", "link is expired, send the reset link again"));
        }

        if (email != null) {

            String hashed = passwordEncoder.encode(password);
            try {
                loginDao.changePassword(hashed, email);
                loginDao.deleteReset_password(email);
                return ResponseEntity.ok(Map.of("message" , "password updated"));
            } catch (Exception e) {
                return ResponseEntity.status(404).body(Map.of("message", "could not update"));
            }
        }
        return ResponseEntity.status(404).body(Map.of("message", "couldnt reset password"));


    }
}


