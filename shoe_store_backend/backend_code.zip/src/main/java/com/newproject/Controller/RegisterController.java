package com.newproject.Controller;

import com.newproject.DTO.RegisterForm;
import com.newproject.service.RegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;
@RestController
@RequestMapping("/api/auth")

public class RegisterController {

    @Autowired
    RegisterService registerService;

    @PostMapping("/register")
    public ResponseEntity<?> Login(@RequestBody RegisterForm registerForm) {
        String username = registerForm.getUsername();
        String password = registerForm.getPassword();
        String email = registerForm.getEmail();
        String fullname = registerForm.getFullname();
        validateEmail(email);
        validatePassword(password);
        validateUsername(username);
        validateFullname(fullname);
        boolean isInserted = registerService.setRegister(fullname, email, username, password);

        if (isInserted) {
            return ResponseEntity.ok(Map.of("message", "Registration succesfull!"));
        } else {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "could not insert!");
        }

    }

    private void validateUsername(String username) {

        if (username == null || username.isBlank()) {

            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "username is required");
        }
    }

    private void validateEmail(String email) {

        if (email == null || email.isBlank()) {

            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "email is required");
        }

    }

    private void validatePassword(String password) {

        if (password == null || password.isBlank()) {

            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "password is required");
        }

    }

    private void validateFullname(String fullname){
        if(fullname == null || fullname.isBlank()){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Fullname is required");
        }
    }

}
