package com.newproject.Controller;


import com.newproject.DAO.ProductsDao;
import com.newproject.DTO.OrderInfoDTO;
import com.newproject.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Map;

@RestController

@RequestMapping("/api/v2")
public class ProductController {

    @Autowired
    ProductService productService;

    @Autowired
    ProductsDao productsDao;

    @Autowired
    FileUploadController fileUploadController;


    @GetMapping("/allproducts")

    public ResponseEntity<List<Map<String, Object>>> allProducts(@RequestParam(defaultValue = "1") int page) {

        List<Map<String, Object>> allproducts = productService.geAllproducts(page);

        if (!allproducts.isEmpty()) {

            return ResponseEntity.ok(allproducts);
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "failed to fetch from DB");
        }
    }


    @GetMapping("/men-products")

    public ResponseEntity<List<Map<String, Object>>> allMenProducts(@RequestParam(defaultValue = "1") int page) {

        List<Map<String, Object>> allproducts = productService.geAllMenproducts(page);

        if (!allproducts.isEmpty()) {

            return ResponseEntity.ok(allproducts);
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "failed to fetch from DB");
        }
    }


    @GetMapping("/women-products")

    public ResponseEntity<List<Map<String, Object>>> womentAllProducts(@RequestParam(defaultValue = "1") int page) {

        List<Map<String, Object>> allproducts = productService.geAllWomenproducts(page);

        if (!allproducts.isEmpty()) {

            return ResponseEntity.ok(allproducts);
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "failed to fetch from DB");
        }
    }


    @GetMapping("/kids-products")

    public ResponseEntity<List<Map<String, Object>>> kidsAllProducts(@RequestParam(defaultValue = "1") int page) {

        List<Map<String, Object>> allproducts = productService.geAllKidsproducts(page);

        if (!allproducts.isEmpty()) {

            return ResponseEntity.ok(allproducts);
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "failed to fetch from DB");
        }
    }

    @GetMapping("/search-products")
    public ResponseEntity<?> searchProduct(@RequestParam String query) {
        System.out.println("hitting");
        List<Map<String, Object>> result = productService.searchProduct(query);

        return ResponseEntity.ok(result);


    }


    @GetMapping("/product")
    public ResponseEntity<?> handleProduct(@RequestParam int product_id) {

        List<Map<String, Object>> info = productsDao.getProductInfo(product_id);
        Map<String, Object> data = info.get(0);

        return ResponseEntity.ok(Map.of("message", "product details fetched successfully", "data", data));

    }

    @PostMapping("/addtocart")
    public ResponseEntity<?> addToCart(@RequestBody OrderInfoDTO orderInfoDTO) {

        String productname = orderInfoDTO.getProduct_name();
        double productprice = orderInfoDTO.getProduct_price();
        int productId = orderInfoDTO.getProduct_id();
        int userId = orderInfoDTO.getUser_id();
        String productUrl = orderInfoDTO.getProduct_url();


        boolean isAddedToCart = productService.addToCart(productId, productname, productprice, userId, productUrl);

        if (isAddedToCart) {
            return ResponseEntity.ok(Map.of("message", "added to cart!"));
        } else {
            return ResponseEntity.status(409).body(Map.of("message", "item already in cart"));
        }
    }

    @PostMapping("/add-to-wishlist")
    public ResponseEntity<?> addtowishlist(@RequestBody OrderInfoDTO orderInfoDTO) {

        String productname = orderInfoDTO.getProduct_name();
        int productprice = orderInfoDTO.getProduct_price();
        int productId = orderInfoDTO.getProduct_id();
        int userId = orderInfoDTO.getUser_id();
        String productUrl = orderInfoDTO.getProduct_url();
        System.out.println("user id is === " + userId);
        try {
            productService.addToWishlist(productname, productId, productprice, productUrl, userId);
            return ResponseEntity.ok(Map.of("message", "added to wishlist!"));
        } catch (RuntimeException e) {
            throw new RuntimeException(e);
        }
    }


    @GetMapping("/get-wishlist")
    public ResponseEntity<?> getWishlist(@RequestParam int user_id) {

        List<Map<String, Object>> wishlist = productsDao.getWishlist(user_id);
        System.out.println(wishlist);
        return ResponseEntity.ok(wishlist);
    }


    @GetMapping("/getcart")
    public ResponseEntity<?> getCart(@RequestParam int user_id) {

        List<Map<String, Object>> cart = productsDao.getCart(user_id);

        return ResponseEntity.ok(cart);
    }

    @DeleteMapping("/deleteitem")
    public ResponseEntity<?> deleteItem(@RequestParam int user_id, @RequestParam int product_id) {


        boolean deleted = productService.deleteItem(user_id, product_id);

        if (deleted) {
            return ResponseEntity.ok(Map.of("message", "item deleted!"));
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "something went wrong");

        }
    }

    @DeleteMapping("/remove-from-wishlist")
    public ResponseEntity<?> removeFromWishlist(@RequestParam int user_id, @RequestParam int product_id) {

        productService.removeFromWishlist(user_id, product_id);

        return ResponseEntity.ok(Map.of("message", "item removed from wishlist!"));

    }


    @DeleteMapping("/alldelete")
    public ResponseEntity<?> allDelete(@RequestParam int user_id) {


        boolean isAlldeleted = productService.deleteAll(user_id);

        if (isAlldeleted) {
            return ResponseEntity.ok(Map.of("message", "all item deleted!"));
        } else {
            return ResponseEntity.status(404).body(Map.of("message", "cart is already empty"));
        }
    }

    @PostMapping("submit-comment")
    public ResponseEntity<?> handleSubmitComment(@RequestParam String comment, @RequestParam int product_id, @RequestParam String username) {

        productService.submitComment(comment, product_id, username);

        return ResponseEntity.ok(Map.of("message", "comment added successfully"));
    }

    @GetMapping("view-comment")
    public ResponseEntity<?> handleViewComment(@RequestParam int product_id) {

        List<Map<String, Object>> data = productService.viewComment(product_id);

        return ResponseEntity.ok(Map.of("message", "comment fetched successfuly", "data", data));
    }
}

