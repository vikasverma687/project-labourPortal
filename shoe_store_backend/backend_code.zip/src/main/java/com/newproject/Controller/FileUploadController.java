package com.newproject.Controller;

import com.newproject.DAO.ProductsDao;
import com.newproject.DTO.ProductInfo;
import com.newproject.service.FileStorageService;
import com.newproject.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;

@RequestMapping("/api/admin/files")
@RestController
public class FileUploadController {

    private final FileStorageService fileStorageService;
    private final ProductsDao productsDao;

    protected String imageurl = "";
    @Autowired
    ProductService productService;


    public FileUploadController(FileStorageService fileStorageService, ProductsDao productsDao) {

        this.fileStorageService = fileStorageService;
        this.productsDao = productsDao;
    }

    @PostMapping("/upload")
    public ResponseEntity<?> uploadFile(@RequestParam("file") MultipartFile file) {


        if (file.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Please select an image to upload");
        }

        imageurl = fileStorageService.saveFile(file);


        System.out.println("url is " + imageurl);

        return ResponseEntity.status(200).body(Map.of("message", "file uploaded successfully", "url", imageurl));


    }

    @PostMapping("/add-product")
    public ResponseEntity<?> addProduct(@RequestBody ProductInfo productInfo) {


        int product_id = productInfo.getProduct_id();
        String product_name = productInfo.getProduct_name();
        int product_price = productInfo.getProduct_price();
        String url = productInfo.getImageurl();
        String product_info = productInfo.getProduct_info();
        int product_rating = productInfo.getRating();

        if (!checkProduct_id(product_id) || !checkProduct_name(product_name)) {

            fileStorageService.deleteFile(imageurl);
            throw new IllegalArgumentException("product name or product id can not be bull or 0");
        }


        if (productsDao.addproduct(product_id, product_name, product_price, url, product_info, product_rating)) {
            productService.clearCacheItems();
            return ResponseEntity.ok(Map.of("message", "product details inserted successuflly"));
        } else {
            fileStorageService.deleteFile(imageurl);

            throw new ResponseStatusException(HttpStatus.CONFLICT, "problemetic query, or Conflict with details in db");
        }

    }

    private boolean checkProduct_id(int id) {
        if (id == 0) {
            return false;
        }
        return true;
    }

    private boolean checkProduct_name(String name) {

        if (name == null) {
            return false;
        }
        return true;
    }

    @DeleteMapping("remove-product")
    public ResponseEntity<?> handleRemoveProduct(@RequestParam int product_id) {

        if (productsDao.removeProduct(product_id)) {
            productService.clearCacheItems();

            return ResponseEntity.ok(Map.of("message", "product remvoved successfully"));
        }
        throw new ResponseStatusException(HttpStatus.NOT_FOUND, "something went wrong removing item");
    }
}
