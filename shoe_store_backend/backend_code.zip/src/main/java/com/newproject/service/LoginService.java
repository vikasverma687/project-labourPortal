package com.newproject.service;

import com.newproject.DAO.LoginDao;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

@Service
public class LoginService {

    @Autowired
    LoginDao loginDao;

    @Autowired
    JwtService jwtService;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    JavaMailSender mailSender;

    public String tryRefreshToken(String email, String role) {

        Date expiry = loginDao.getRTExpiry(email);

        if (expiry.before(new Date())) {

            loginDao.deleteRT(email);
            return null;
        }
        return jwtService.generateToken(email, role);

    }

    public boolean setLogin(String email, String password) {

        String getpass = loginDao.getPassword(email);

        return passwordEncoder.matches(password, getpass);

    }

    public boolean setRefreshToken(String token, String email) {

        Claims claims = jwtService.parseClaims(token);
        Date issued = claims.getIssuedAt();
        Date expiry = claims.getExpiration();

        return loginDao.setRefreshToken(email, token, issued, expiry);

    }

    public boolean getResetLink(String email) {


        if (loginDao.getEmail(email) == null) {
            return false;
        } else {

            String token = UUID.randomUUID().toString();

            Date expiry = new Date(System.currentTimeMillis() + 1000 * 60 * 15);

            try {
                loginDao.saveResetToken(token, expiry, email);
            } catch (Exception e) {
                System.out.println(e.getMessage());
                throw new RuntimeException("problem in password reset service or dao", e);
            }

            SimpleMailMessage message = new SimpleMailMessage();

            String link = "http://localhost:3001/PasswordReset?token="+token;

            message.setTo(email);
            message.setSubject("password reset link");
            message.setText("password reset link, will expire in 15 min. = " + link);
            mailSender.send(message);

            System.out.println("link sent to mail = " + email);
            return true;
        }
    }

}
