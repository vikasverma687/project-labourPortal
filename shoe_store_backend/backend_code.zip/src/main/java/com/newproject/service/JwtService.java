package com.newproject.service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class JwtService {


    private static final String SECRET = "mysecretkeymysecretkeymysecretkey123";

    private static final long EXPIRATION_MS = 1000 * 60 * 15;
    private static final long REFRESH_EXPIRATIO_MS = 1000 * 60 * 60 * 24 * 7;


    private Key getSigningKey() {
        return Keys.hmacShaKeyFor(SECRET.getBytes());
    }


    public Claims parseClaims(String token) {
        return Jwts.parser()
                .verifyWith((SecretKey) getSigningKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    public String generateToken(String email1, String role) {

        Map<String, Object> claim = new HashMap<>();
        claim.put("role", role);
        return Jwts.builder()
                .claims(claim)
                .subject(email1)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + EXPIRATION_MS))
                .signWith(getSigningKey())
                .compact();
    }

    public String generateRefreshToken(String email ) {
        return Jwts.builder()
                .signWith(getSigningKey())
                .subject(email)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis()+ REFRESH_EXPIRATIO_MS))
                .compact();
    }


}
