package com.newproject.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Service
public class FileStorageService {

    @Value("${file.upload-dir}")
    private String uploadDir;

    public String saveFile(MultipartFile file) {

        File folder = new File(uploadDir);
        try {
            if (!folder.exists()) {

                folder.mkdirs();
            }

            String filename = UUID.randomUUID() + "_" + file.getOriginalFilename();

            Path filepath = Paths.get(uploadDir, filename);

            Files.copy(file.getInputStream(), filepath, StandardCopyOption.REPLACE_EXISTING);

            return "/" + uploadDir + "/" + filename;
        } catch (IOException e) {
            throw new RuntimeException("failed to save file");
        }
    }

    public void deleteFile(String url){
       try {
           Path filepath = Paths.get( url.substring(1));

        boolean isDeleted =    Files.deleteIfExists(filepath);

        if(isDeleted){
            System.out.println("file deleted successfully");
        }else{
            System.out.println("couldnt delete some issue");
        }
       } catch (IOException e) {
           System.out.println("failed to delete"+ e.getMessage());
       }

    }
}
