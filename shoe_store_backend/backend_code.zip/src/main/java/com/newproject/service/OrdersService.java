package com.newproject.service;

import com.newproject.DAO.OrdersDao;
import com.newproject.exception.PlaceOrderException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class OrdersService {

    @Autowired
    OrdersDao ordersDao;

    @Autowired
    JdbcTemplate jdbcTemplate;

    public void placeorder(int userId) {

        List<Map<String, Object>> products = jdbcTemplate.queryForList("SELECT * FROM allcarts WHERE user_id = ?", userId);

        if (products.isEmpty()) {
            throw new PlaceOrderException(HttpStatus.NOT_FOUND, "no items in your cart ");
        }
        ordersDao.placeOrders(products, userId);

        jdbcTemplate.update("DELETE  FROM allcarts where user_id = ?", userId);
    }


    public List<Map<String, Object>> fetchOrders(int userId) {

        return ordersDao.fetchOrders(userId);
    }


}
