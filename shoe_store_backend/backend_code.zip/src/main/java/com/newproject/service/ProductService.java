package com.newproject.service;


import com.newproject.DAO.ProductsDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class ProductService {

    @Autowired
    ProductsDao productsDao;

    @Cacheable(value = "HomePageProducts", key = "#page")
    public List<Map<String, Object>> geAllproducts(int page) {
        return productsDao.geAllproducts(page);
    }

    public List<Map<String, Object>> geAllMenproducts(int page) {
        return productsDao.geAllMenproducts(page);
    }

    public List<Map<String, Object>> geAllWomenproducts(int page) {
        return productsDao.geAllWomenproducts(page);
    }

    public List<Map<String, Object>> geAllKidsproducts(int page) {
        return productsDao.geAllKidsproducts(page);
    }


    public List<Map<String, Object>> searchProduct(String query) {

        return productsDao.searchProduct(query );

    }

    public void addToWishlist(String productname, int productId, int productprice, String productUrl, int userId) {

        productsDao.addToWishlist(productname, productId, productprice, productUrl, userId);

    }

    public boolean addToCart(int productId, String productName, double productPrice, int userId, String productUrl) {

        return productsDao.addToCart(productId, productName, productPrice, userId, productUrl);
    }

    public boolean deleteItem(int user_id, int product_id) {
        return productsDao.deleteItem(user_id, product_id);
    }

    public void removeFromWishlist(int userId, int productId) {

        try {
            System.out.println("delete is workijng");
            productsDao.removeFromWishlist(productId, userId);
        } catch (RuntimeException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean deleteAll(int user_id) {
        return productsDao.deleteAll(user_id);
    }

    @CacheEvict(value = "HomePageProducts", allEntries = true)
    public void clearCacheItems() {

    }

    public void submitComment(String comment, int product_id, String username) {
        productsDao.submitComment(comment, product_id, username);
    }

    public List<Map<String, Object>> viewComment(int product_id) {

        return productsDao.viewComment(product_id);
    }

}
