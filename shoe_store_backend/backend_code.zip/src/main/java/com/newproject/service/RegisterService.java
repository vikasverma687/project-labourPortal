package com.newproject.service;

import com.newproject.DAO.RegisterDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class RegisterService {

@Autowired
    RegisterDao registerDao;


    @Autowired
    PasswordEncoder passwordEncoder;

    public boolean setRegister( String fullname ,String email , String username, String password){

        String hashed = passwordEncoder.encode(password);
        return registerDao.setRegister(fullname ,email,username,hashed);

    }
}
