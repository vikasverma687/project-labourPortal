package com.newproject.DataInitializer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class Initializer {

    @Autowired
    PasswordEncoder passwordEncoder;

    @Bean
    CommandLineRunner commandLineRunner(JdbcTemplate jdbcTemplate) {

        return args -> {

            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS login(" +
                    "id SERIAL PRIMARY KEY," +
                    "email VARCHAR(255) UNIQUE NOT NULL," +
                    "full_name VARCHAR(255) NOT NULL, " +
                    "username  VARCHAR(255) UNIQUE NOT NULL, " +
                    "password  VARCHAR(255)  NOT NULL," +
                    "role  VARCHAR(255)  DEFAULT 'USER')");

            String password = "123";
            String hashed = passwordEncoder.encode(password);

            int row = jdbcTemplate.queryForObject("SELECT count(*) FROM login", Integer.class);

            if (row <= 0) {
                jdbcTemplate.update("INSERT INTO login(email, full_name, username, password, role) VALUES(?,?,?,?,?)",
                        "admin@123", "admin", "admin", hashed, "ADMIN");
            }
            System.out.println("=============>started");

            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS allproducts(" +
                    "id SERIAL PRIMARY KEY," +
                    "product_id INT UNIQUE NOT NULL," +
                    "product_name VARCHAR(255) NOT NULL," +
                    "product_price DECIMAL(10 , 2) NOT NULL," +
                    "product_url VARCHAR(255) NOT NULL," +
                    "product_info VARCHAR NOT NULL DEFAULT 'this is a good product'," +
                    "rating INT NOT NULL DEFAULT '5')");


            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS menproducts(" +
                    "id SERIAL PRIMARY KEY," +
                    "product_id INT UNIQUE NOT NULL," +
                    "product_name VARCHAR(255) NOT NULL," +
                    "product_price DECIMAL(10 , 2) NOT NULL," +
                    "product_url VARCHAR(255) NOT NULL," +
                    "product_info VARCHAR NOT NULL DEFAULT 'this is a good product'," +
                    "rating INT NOT NULL DEFAULT '5')");


            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS womenproducts(" +
                    "id SERIAL PRIMARY KEY," +
                    "product_id INT UNIQUE NOT NULL," +
                    "product_name VARCHAR(255) NOT NULL," +
                    "product_price DECIMAL(10 , 2) NOT NULL," +
                    "product_url VARCHAR(255) NOT NULL," +
                    "product_info VARCHAR NOT NULL DEFAULT 'this is a good product'," +
                    "rating INT NOT NULL DEFAULT '5')");

            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS kidsproducts(" +
                    "id SERIAL PRIMARY KEY," +
                    "product_id INT UNIQUE NOT NULL," +
                    "product_name VARCHAR(255) NOT NULL," +
                    "product_price DECIMAL(10 , 2) NOT NULL," +
                    "product_url VARCHAR(255) NOT NULL," +
                    "product_info VARCHAR NOT NULL DEFAULT 'this is a good product'," +
                    "rating INT NOT NULL DEFAULT '5')");

            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS wishlist(" +
                    "id SERIAL PRIMARY KEY," +
                    "product_id INT NOT NULL," +
                    "product_name VARCHAR(255) NOT NULL," +
                    "product_price DECIMAL(10 , 2) NOT NULL," +
                    "product_url VARCHAR(255) NOT NULL ,"+
                    "user_id INT NOT NULL ,"+
                    "CONSTRAINT unique_user_product_allwishlist UNIQUE(user_id , product_id))"
            );


            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS allcarts(" +
                    "id SERIAL PRIMARY KEY," +
                    "user_id INT NOT NULL," +
                    "product_id INT NOT NULL," +
                    "product_name VARCHAR(255) NOT NULL," +
                    "product_price INT NOT NULL," +
                    "product_url VARCHAR," +
                    "CONSTRAINT unique_user_product UNIQUE(user_id , product_id)" +
                    ")"
            );

            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS rt_table(" +
                    "id SERIAL PRIMARY KEY," +
                    "email VARCHAR UNIQUE NOT NULL," +
                    "token VARCHAR UNIQUE NOT NULL," +
                    "issued_at VARCHAR NOT NULL," +
                    "expiry_at VARCHAR NOT NULL)");

            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS reset_password(" +
                    "token VARCHAR NOT NULL," +
                    "expiry TIMESTAMP NOT NULL," +
                    "email VARCHAR NOT NULL)");

            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS allorders(" +
                    "id SERIAL PRIMARY KEY," +
                    "user_id INT NOT NULL," +
                    "product_name VARCHAR NOT NULL," +
                    "product_price INT NOT NULL," +
                    "product_id INT UNIQUE NOT NULL," +
                    "product_url VARCHAR NOT NULL," +
                    "CONSTRAINT unique_user_product_allorders UNIQUE(user_id , product_id))");

            jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS product_comment(" +
                    "id SERIAL PRIMARY KEY," +
                    "product_id INT NOT NULL," +
                    "comment VARCHAR(255) NOT NULL," +
                    "user_name VARCHAR NOT NULL)");

            // Run migration only if table is empty

            Integer all = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM allproducts", Integer.class);
            if (all != null && all == 0) {
                ClassPathResource resource = new ClassPathResource("db/V0_seed_all_products.sql");
                String sql = new String(resource.getInputStream().readAllBytes());
                jdbcTemplate.execute(sql);
                System.out.println("Seeded  ALL 100 products.");
            } else {
                System.out.println("ALLProducts table already has data, skipping seed.");
            }

            Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM menproducts", Integer.class);
            if (count != null && count == 0) {
                ClassPathResource resource = new ClassPathResource("db/V1__seed_men_products.sql");
                String sql = new String(resource.getInputStream().readAllBytes());
                jdbcTemplate.execute(sql);
                System.out.println("Seeded 100 products.");
            } else {
                System.out.println("menProducts table already has data, skipping seed.");
            }


            Integer c = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM womenproducts", Integer.class);

            if (c != null && c == 0) {
                ClassPathResource resource = new ClassPathResource("db/V2_seed_women_products.sql");
                String sql = new String(resource.getInputStream().readAllBytes());
                jdbcTemplate.execute(sql);

                System.out.println("women products seeded");

            } else {
                System.out.println("women products already exists!!");

            }

            Integer k = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM kidsproducts", Integer.class);

            if (k != null && k == 0) {

                ClassPathResource resource = new ClassPathResource("db/V3_seed_kids_products.sql");
                String sql = new String(resource.getInputStream().readAllBytes());
                jdbcTemplate.execute(sql);

                System.out.println("Kids products seeded");
            } else {
                System.out.println("kids products already seeded!");
            }
        };
    }


}
