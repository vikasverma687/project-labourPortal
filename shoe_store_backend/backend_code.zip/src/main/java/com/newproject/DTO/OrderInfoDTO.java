package com.newproject.DTO;

import lombok.Data;

@Data
public class OrderInfoDTO {


    private int user_id;
    private String product_name;
    private  int product_price;
    private int product_id;
    private String product_url;
}
