package com.newproject.DTO;

import lombok.Data;

@Data
public class PlacedOrdersDTO {

    private String product_name;
    private int product_id;
    private int product_price;

}
