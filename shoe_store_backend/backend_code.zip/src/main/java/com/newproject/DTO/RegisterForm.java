package com.newproject.DTO;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data

public class RegisterForm {

private String email;
private String fullname;
private String password;
private String username;

}
