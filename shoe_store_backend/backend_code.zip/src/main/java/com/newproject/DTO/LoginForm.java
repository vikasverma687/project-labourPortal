package com.newproject.DTO;

import lombok.Data;

import lombok.Getter;
import lombok.Setter;

@Data

public class LoginForm {

private String email;
private String password;


}
