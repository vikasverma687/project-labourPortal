package com.newproject.DTO;

import lombok.Data;

@Data
public class ProductInfo {

   private String product_name;
   private int product_price;
   private int product_id;
   private String imageurl;
   private String product_info;
   private int rating;


}
