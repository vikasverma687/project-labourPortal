package com.newproject.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

@Getter
public class PlaceOrderException extends RuntimeException {

    private final HttpStatus status;

    public PlaceOrderException(HttpStatus status,String message) {
        super(message);
        this.status = status;
    }
}
