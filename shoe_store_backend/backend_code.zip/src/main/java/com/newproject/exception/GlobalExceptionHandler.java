package com.newproject.exception;

import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;

import javax.xml.crypto.Data;
import java.io.IOException;
import java.util.Map;
import java.util.Optional;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<?> handleResponseStatusException(ResponseStatusException ex) {
        return ResponseEntity
                .status(ex.getStatusCode())
                .body(Map.of(
                        "status", ex.getStatusCode().value(),
                        "message", Optional.ofNullable(ex.getReason()).orElse("Something went wrong. Our team has been notified.")
                ));
    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<?> handleRuntimeException(RuntimeException ex){
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(Map.of("message", Optional.ofNullable(ex.getMessage()).orElse("internal problem with your request")
                ));
    }

    @ExceptionHandler(PlaceOrderException.class)
    public ResponseEntity<?> handlePlaceOrderException(PlaceOrderException ex){
        return ResponseEntity
                .status(ex.getStatus())
                .body(Map.of("message", Optional.ofNullable(ex.getMessage()).orElse("internal problem with your request")
                ));
    }

    @ExceptionHandler(IllegalAccessException.class)
    public ResponseEntity<?> handleIllegalAruguments(IllegalArgumentException ill){
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Map.of("message",Optional.ofNullable(ill.getMessage()).orElse("something worng with passed arguments"))
                );
    }

    @ExceptionHandler(IOException.class)
    public ResponseEntity<?>handleIOException(IOException io){
        return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).
                body(Map.of("message",io.getMessage()));
    }

    @ExceptionHandler(OrdersAlreadyPlacedException.class)
    public ResponseEntity<?>handleOrdersAlreadyPlaced(OrdersAlreadyPlacedException op){
        return ResponseEntity.status(op.getStatus()).body(Map.of("message", op.getMessage()));
    }

    @ExceptionHandler(ItemsConflictException.class)
    public ResponseEntity<?>handleItemsConfliCtException(ItemsConflictException it){
        return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(Map.of("message", it.getMessage()));
    }

    @ExceptionHandler(DataAccessException.class)
    public ResponseEntity<?> handleDataException(DataAccessException da){
        return ResponseEntity.status(404).body(Map.of("message" , da.getMessage()));
    }
}
