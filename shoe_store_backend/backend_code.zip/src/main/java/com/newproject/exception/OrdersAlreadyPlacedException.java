package com.newproject.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class OrdersAlreadyPlacedException extends RuntimeException {

    private final HttpStatus status;

    public OrdersAlreadyPlacedException(HttpStatus status, String message) {
        super(message);
        this.status = status;
    }

}
