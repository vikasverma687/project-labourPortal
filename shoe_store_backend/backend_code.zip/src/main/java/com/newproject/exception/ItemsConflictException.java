package com.newproject.exception;

public class ItemsConflictException extends RuntimeException {
    public ItemsConflictException(String message) {
        super(message);
    }
}
