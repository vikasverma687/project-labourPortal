package com.newproject.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


@Repository

public class RegisterDao {

    @Autowired
    JdbcTemplate jdbcTemplate;

    public boolean setRegister(String fullname ,  String email , String username ,String password){

        try {
            int row = jdbcTemplate.update("INSERT INTO login( full_name, email, username , password) VALUES(?,?,?,?)",
                    fullname, email, username, password);
            return row > 0;
        }catch (Exception e){
            throw new RuntimeException("email or username already exists");

        }
    }
}
