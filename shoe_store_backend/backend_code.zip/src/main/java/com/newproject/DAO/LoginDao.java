package com.newproject.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.web.server.ResponseStatusException;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Repository

public class LoginDao {

    @Autowired
    JdbcTemplate jdbcTemplate;


    public boolean setLogin(String email, String password) {


        Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM  login WHERE email = ? AND password = ? ", Integer.class, email, password);
        return count != null && count > 0;
    }

    public String getPassword(String email){
        return jdbcTemplate.queryForObject("SELECT password FROM login WHERE email = ?", String.class, email);
    }

    public  String getEmail(String email){

        return   jdbcTemplate.queryForObject("select count(*) from login where email = ?", String.class,email);


    }

    public boolean saveResetToken(String token , Date expiry , String email){

        int row = jdbcTemplate.update("INSERT INTO reset_password(token , expiry, email) VALUES(?,?,?)" ,token,expiry,email);

        return row>0;
    }

    public List<Map<String, Object>> getEmailExpiryByToken(String token){

       List<Map<String,Object>>row =  jdbcTemplate.queryForList("SELECT email, expiry from reset_password WHERE token = ?",token);

       return row;
    }

    public void changePassword(String password ,String email){

         jdbcTemplate.update("UPDATE login SET password = ? WHERE email  = ?",password, email);
System.out.println("password updated successfully!!!");
    }

    public void deleteReset_password(String email){
        jdbcTemplate.update("DELETE FROM reset_password WHERE email = ?",email);
    }


    public int getUserId(String email) {
        try {
            return jdbcTemplate.queryForObject("SELECT id FROM login where email = ?", Integer.class, email);

        } catch (Exception e) {
            System.out.println("couldnt found id");

            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "couldnt found id in DB");
        }
    }

    public String getUsername(String username){

        try {
            return jdbcTemplate.queryForObject("SELECT username FROM login WHERE email = ?", String.class, username);
        } catch (DataAccessException e) {
            throw new RuntimeException(e);
        }
    }

    public String getRole(String email) {
        try {
            return jdbcTemplate.queryForObject("SELECT role FROM login WHERE email =?", String.class, email);
        } catch (DataAccessException e) {
            throw new RuntimeException("sql query mistake probably!!", e);
        }
    }

    public String getRT(String email) {

        try {


            return jdbcTemplate.queryForObject("SELECT token FROM rt_table where email =?", String.class, email);
        } catch (Exception e) {
            return null;
        }
    }

    public boolean setRefreshToken(String email, String token, Date issued, Date expiry) {
        try {
            int row = jdbcTemplate.update("INSERT INTO rt_table(email,token , issued_at, expiry_at) VALUES(?,?,?,?)", email, token, issued, expiry);

            return row > 0;
        } catch (DataAccessException e) {
            throw new RuntimeException("check sql query", e);
        }
    }

    public Date getRTExpiry(String email) {

        try {

            return jdbcTemplate.queryForObject("SELECT expiry_at FROM rt_table WHERE email=?", Date.class, email);
        } catch (DataAccessException e) {
            throw new RuntimeException("check sql query!", e);

        }
    }

    public void deleteRT(String email) {

        jdbcTemplate.update("DELETE FROM rt_table WHERE email=?", email);

    }
}
