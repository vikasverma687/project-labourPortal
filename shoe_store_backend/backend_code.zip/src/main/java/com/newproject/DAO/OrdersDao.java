package com.newproject.DAO;

import com.newproject.exception.OrdersAlreadyPlacedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class OrdersDao {


    @Autowired
    JdbcTemplate jdbcTemplate;

    public void placeOrders(List<Map<String, Object>> products, int userId) {

        for (Map<String, Object> item : products) {

            int product_id = (int) item.get("product_id");
            int product_price = (int) item.get("product_price");
            String product_name = (String) item.get("product_name");
            String product_url = (String) item.get("product_url");

            try {
                jdbcTemplate.update("INSERT INTO allorders(user_id , product_id , product_name, product_price, product_url) VALUES(?,?,?,?,?)",
                        userId, product_id, product_name, product_price, product_url);
            } catch (DataAccessException e) {
                throw new OrdersAlreadyPlacedException(HttpStatus.CONFLICT,"items are already placed");

            }
        }
    }

    public List<Map<String, Object>> fetchOrders(int userId) {
        try {
            return jdbcTemplate.queryForList("SELECT * FROM allorders where user_id = ?", userId);

        } catch (DataAccessException e) {
            return null;
        }
    }

    public boolean removeItem(int userId, int product_id) {

        int row = jdbcTemplate.update("DELETE FROM allorders WHERE user_id = ? AND product_id=?", userId, product_id);
        return row > 0;
    }

    public void deleteAll(int userId){

        jdbcTemplate.update("DELETE FROM allorders WHERE user_id = ?", userId);
    }

}
