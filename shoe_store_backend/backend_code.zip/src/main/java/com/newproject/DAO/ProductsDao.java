package com.newproject.DAO;


import com.newproject.exception.ItemsConflictException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class ProductsDao {

    @Autowired
    JdbcTemplate jdbcTemplate;

    public boolean addproduct(int id, String name, int price, String url, String info, int rating) {
        try {
            int row = jdbcTemplate.update("INSERT INTO allproducts(product_id, product_name, product_price, product_url,product_info , rating) VALUES(?,?,?,?,?,?)",
                    id, name, price, url, info, rating);
            return row > 0;
        } catch (DataAccessException e) {
            throw new ItemsConflictException(" product details already exists, please change product_id");
        }
    }

    public List<Map<String, Object>> searchProduct(String query ){

        String sql = "SELECT * FROM allproducts WHERE LOWER(product_name) LIKE LOWER(?) LIMIT 30";

    return jdbcTemplate.queryForList(sql, "%" + query +"%" );
    }


    public void addToWishlist(String productname ,int productId ,int productprice ,String productUrl ,int userId){
    System.out.println("user id is" + userId);
      jdbcTemplate.update("INSERT INTO wishlist( product_id , product_name , product_price , product_url , user_id) VALUES(?,?,?,?,?)",productId , productname , productprice , productUrl , userId);
    }

    public boolean removeProduct(int product_id) {

        int row = jdbcTemplate.update("DELETE FROM allproducts WHERE product_id = ?", product_id);

        if (row <= 0) {
            throw new DataAccessException("no product exist with that product id") {
            };
        }
        return true;


    }

    public void removeFromWishlist(int productId, int user_id){
        System.out.println("delete is workijng");
     jdbcTemplate.update("DELETE FROM wishlist WHERE product_id = ? and user_id = ?",productId, user_id);

    }

    public boolean addProductInfo(int product_id, String info, int rating) {
        System.out.println("rating is = " + rating + "and product info is = " + info);
        try {
            int row = jdbcTemplate.update("INSERT INTO productInfo( product_id ,product_info , product_rating) VALUES(?,?,?)", product_id, info, rating);
            return row > 0;
        } catch (DataAccessException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Map<String, Object>> getProductInfo(int product_id) {


        if (product_id >= 1 && product_id <= 100) {
            return jdbcTemplate.queryForList("SELECT * from allproducts where product_id=?", new Object[]{product_id});

        } else if (product_id >= 1002 && product_id <= 1100) {
            return jdbcTemplate.queryForList("SELECT * from menproducts where product_id=?", new Object[]{product_id});

        } else if (product_id >= 1101 && product_id <= 1186) {
            return jdbcTemplate.queryForList("SELECT * from womenproducts where product_id=?", new Object[]{product_id});

        } else if (product_id >= 1190 && product_id <= 1224) {
            return jdbcTemplate.queryForList("SELECT * from kidsproducts where product_id=?", new Object[]{product_id});

        }
        throw new RuntimeException("something went wrong, fetching details!!");
    }

    public List<Map<String, Object>> geAllproducts(int page) {
        int limit = 8;
        int offset = (page - 1) * limit;

        return jdbcTemplate.queryForList("SELECT * FROM allproducts  LIMIT ? OFFSET ?", limit, offset);

    }


    public List<Map<String, Object>> geAllMenproducts(int page) {
        int limit = 8;
        int offset = (page - 1) * limit;

        return jdbcTemplate.queryForList("SELECT * FROM menproducts  LIMIT ? OFFSET ?", limit, offset);

    }

    public List<Map<String, Object>> geAllWomenproducts(int page) {
        int limit = 8;
        int offset = (page - 1) * limit;

        return jdbcTemplate.queryForList("SELECT * FROM womenproducts  LIMIT ? OFFSET ?", limit, offset);

    }


    public List<Map<String, Object>> geAllKidsproducts(int page) {
        int limit = 8;
        int offset = (page - 1) * limit;

        return jdbcTemplate.queryForList("SELECT * FROM kidsproducts  LIMIT ? OFFSET ?", limit, offset);

    }

    public boolean addToCart(int productId, String productName, double productPrice, int userId, String productUrl) {
        try {
            int row = jdbcTemplate.update("INSERT INTO allcarts(product_id , product_name , product_price, user_id, product_url)VALUES(?,?,?,?,?) ON CONFLICT ON CONSTRAINT unique_user_product DO NOTHING",
                    productId, productName, productPrice, userId, productUrl);
            return row > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Map<String, Object>> getCart(int user_id) {

        try {
            return jdbcTemplate.queryForList("SELECT * FROM allcarts where user_id = ?", user_id);

        } catch (DataAccessException e) {
            throw new RuntimeException("table not found", e);
        }
    }


    public List<Map<String, Object>> getWishlist(int user_id) {

        try {
           System.out.println("hitting");
            return jdbcTemplate.queryForList("SELECT * FROM wishlist where user_id = ?", user_id);

        } catch (DataAccessException e) {
            throw new RuntimeException("table not found", e);
        }
    }




    public boolean deleteItem(int user_id, int product_id) {
        try {
            int row = jdbcTemplate.update("DELETE  FROM allcarts WHERE user_id=? AND product_id=? ",
                    user_id, product_id);

            return row > 0;

        } catch (DataAccessException e) {
            throw new RuntimeException("something unexpected happened", e);
        }
    }

    public boolean deleteAll(int user_id) {
        try {
            int row = jdbcTemplate.update("DELETE  FROM allcarts WHERE user_id=?",
                    user_id);
            return row > 0;
        } catch (DataAccessException e) {
            throw new RuntimeException("something unexpected happened", e);
        }
    }

    public void submitComment(String comment, int id, String username) {
        try {

            jdbcTemplate.update("INSERT INTO product_comment(product_id , comment , user_name) values(?,?,?)", id, comment, username);

        } catch (DataAccessException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Map<String, Object>> viewComment(int product_id) {
        try {

            return jdbcTemplate.queryForList("SELECT * FROM product_comment WHERE product_id = ?", product_id);
        } catch (DataAccessException e) {
            throw new RuntimeException("no comments on this product", e);
        }
    }


}
