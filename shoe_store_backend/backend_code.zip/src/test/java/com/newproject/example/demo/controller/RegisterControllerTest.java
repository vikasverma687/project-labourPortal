package com.newproject.example.demo.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class RegisterControllerTest {

    @Autowired
    MockMvc mockMvc;

//
//    @Test
//    void shouldRegisterSuccessfully() throws Exception {
//        mockMvc.perform(post("/api/v1/register")
//                        .contentType(MediaType.APPLICATION_JSON)
//                        .content("""
//                                {
//                                "fullname" : "tester kumar",
//                                "email" : "tester@123",
//                                "username" : "tester",
//                                "password" : "123"
//                                }
//                                """))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.message").value("registation successfull!"));
//    }

    @Test
    void shouldFailedWhenEmailIsMissing() throws Exception {
        mockMvc.perform(post("/api/v1/register")
                        .servletPath("/api/v1/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                "fullname" : "tester kumar",
                                "email" : "",
                                "username" : "tester",
                                "password" : "123"
                                }
                                """))
                .andExpect(status().isBadRequest());
    }


//    @Test
//    void shouldFailedWhenUsernameIsMissing() throws Exception {
//        mockMvc.perform(post("/api/v1/register")
//                        .contentType(MediaType.APPLICATION_JSON)
//                        .content("""
//                                {
//                                "fullname" : "tester kumar"
//                                "email" : "tester@123"
//                                "username" : ""
//                                "password" : "123"
//                                "confirm password" : "123"
//                                }
//                                """))
//                .andExpect(status().isBadRequest());
//    }


//    @Test
//    void shouldFailedWhenFullnameIsMissing() throws Exception {
//        mockMvc.perform(post("/api/v1/register")
//                        .contentType(MediaType.APPLICATION_JSON)
//                        .content("""
//                                {
//                                "fullname" : ""
//                                "email" : "tester@123"
//                                "username" : "tester"
//                                "password" : "123"
//                                "confirm password" : "123"
//                                }
//                                """))
//                .andExpect(status().isBadRequest());
//    }


//    @Test
//    void shouldFailedWhenEmailAlreadyExists() throws Exception {
//
//        String body = """
//                {
//
//                        "fullname" : ""
//                        "email" : "testerDuplicate@123"
//                        "username" : "tester"
//                        "password" : "123"
//                        "confirm password" : "123"
//
//                }
//                """;



}

